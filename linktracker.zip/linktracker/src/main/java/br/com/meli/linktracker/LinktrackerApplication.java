package br.com.meli.linktracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LinktrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinktrackerApplication.class, args);
	}

}
