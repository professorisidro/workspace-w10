package br.com.meli.morsedecoder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MorsedecoderApplicationTests {

	@Test
	void contextLoads() {
	}

}
